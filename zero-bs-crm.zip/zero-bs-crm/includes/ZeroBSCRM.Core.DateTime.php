<?php
/*!
 * Jetpack CRM
 * http://www.zerobscrm.com
 * V2.98.2+
 *
 * Copyright 2020 Automattic
 *
 * Date: 05/03/2019
 */

/* ======================================================
  Breaking Checks ( stops direct access )
   ====================================================== */
    if ( ! defined( 'ZEROBSCRM_PATH' ) ) exit;
/* ======================================================
  / Breaking Checks
   ====================================================== */


   // https://stackoverflow.com/questions/1416697/converting-timestamp-to-time-ago-in-php-e-g-1-day-ago-2-days-ago
   // ^^ so many semi-working solutions