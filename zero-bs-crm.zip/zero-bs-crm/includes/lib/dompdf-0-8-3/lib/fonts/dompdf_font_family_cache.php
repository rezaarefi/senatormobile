<?php return array (
  'notosansglobal' => array(
    'normal' => $fontDir . '/NotoSans-Regular',
    'bold' => $fontDir . '/NotoSans-Bold',
    'italic' => $fontDir . '/NotoSans-Italic',
    'bold_italic' => $fontDir . '/NotoSans-BoldItalic',
  ),
) ?>