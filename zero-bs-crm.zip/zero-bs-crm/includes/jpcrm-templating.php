<?php 
/*!
 * Jetpack CRM
 * https://jetpackcrm.com
 * Copyright 2021 Automattic
 */

/* ======================================================
  Breaking Checks ( stops direct access )
   ====================================================== */
    if ( ! defined( 'ZEROBSCRM_PATH' ) ) exit;
/* ======================================================
  / Breaking Checks
   ====================================================== */



function zeroBSCRM_retrievePDFTemplate($template='default'){

	$templatedHTML = ''; 

	if (function_exists('file_get_contents')){

		#} templates
		// default = inv
		// statement = statemenet
		$acceptableTemplates = array('default','statement');

		if (in_array($template, $acceptableTemplates)){

		            try {

		            	#} Build from default template - see the useful - http://www.leemunroe.com/responsive-html-email-template/
		                $templatedHTML = file_get_contents(ZEROBSCRM_PATH.'html/invoices/pdf-'.$template.'.html');


		            } catch (Exception $e){

		                #} Nada 

		            }

		}

	}

	return $templatedHTML;

}


function zeroBSCRM_retrieveQuoteTemplate($template='default'){

	$templatedHTML = ''; 

	if (function_exists('file_get_contents')){

		#} templates
		$acceptableTemplates = array('default');

		if (in_array($template, $acceptableTemplates)){

		            try {

		            	#} Build from default template - see the useful - http://www.leemunroe.com/responsive-html-email-template/
		                $templatedHTML = file_get_contents(ZEROBSCRM_PATH.'html/quotes/quote-'.$template.'.html');


		            } catch (Exception $e){

		                #} Nada 

		            }

		}

	}

	return $templatedHTML;

}



/* WH Notes:

	There was all this note-age from old vers:
			Customer Meta Translation - 2.90 
			#}PUT THE EMAIL THROUGH THE FILTERS (FOR THE #FNAME# NEW CUSTOMER TAGS do prepare_email_{trigger}_template
			#} WH: Let's do this as filters :)
	
	... but I think these funcs needed a bit of a clean up
	... should be backward compatible, and safe to stick to using the filter: zeroBSCRM_replace_customer_placeholders
	... MC2.0 uses this indirectly through 'zerobscrm_mailcamp_merge' and 'zerobscrm_mailcamp_merge_text'
	... so be careful with it

	... v3.0 I've made them DAL3 safe, not fully refactored as approaching deadline
*/
// Note: this function is deprecated from ~4.3.0, please use $zbs->get_templating()->replace_placeholders()
function zeroBSCRM_replace_customer_placeholders($html = '', $cID = -1, $contactObj = false){

	if ($cID > 0 && $html != ''){

		global $zbs;

		if (is_array($contactObj) && isset($contactObj['id']))
			$contact = $contactObj;
		else {
			if ($zbs->isDAL3())
				// v3.0
				$contact = $zbs->DAL->contacts->getContact($cID,array(
		            'withCustomFields'  => true,
		            // need any of these?
		            'withQuotes'        => false,
		            'withInvoices'      => false,
		            'withTransactions'  => false,
		            'withLogs'          => false,
		            'withLastLog'       => false,
		            'withTags'          => false,
		            'withCompanies'     => false,
		            'withOwner'         => false,
		            'withValues'        => false,
            ));
			else
				// pre v3.0
				$contact = zeroBS_getCustomerMeta($cID);
		}

		// replace all placeholders :)
		$newHTML = $html;
		foreach ($contact as $k => $v){
			$newHTML = str_replace('##CONTACT-'.strtoupper($k) . '##' ,$v, $newHTML);  
		}
		$html = $newHTML;

	}

    return $html;

}

add_filter( 'zerobscrm_quote_html_generate','zeroBSCRM_replace_customer_placeholders', 20, 2);

// as above, but replaces with 'demo data'
function zeroBSCRM_replace_customer_placeholders_demo($html = ''){
	if($html != ''){
		$cust_meta = zeroBS_getDemoCustomer();
		$newHTML = $html;
		foreach($cust_meta as $k => $v){
			$newHTML = str_replace('##CONTACT-'.strtoupper($k) . '##' ,$v, $newHTML);  
		}
		$html = $newHTML;
	}
    return $html;
}
